##It aims to be as modular as possible, allowing adding new features with minor effort.

## Example config file
#6203838763:AAFKHxOaQilei4GnWtvyJ6NPXI03qwhuFI8
##```python
# Your Telegram bot token.
BOT_TOKEN = "6497218079:AAGbg5Ebq_xaHiSK_C30Eqzvn0h8U90xJu0"

# Telegram API ID and Hash. This is NOT your bot token and shouldn't be changed.
API_ID = 9641313
API_HASH = "baefb797b70643121704c7f344b92870"

# Chat used for logging errors.
LOG_CHAT = 5760770665

# Chat used for logging user actions (like buy, gift, etc).
ADMIN_CHAT = 5760770665
GRUPO_PUB = -1002122117674


# How many updates can be handled in parallel.
# Don't use high values for low-end servers.
WORKERS = 20

# Os administradores podem acessar o painel e adicionar novos materiais ao bot.
ADMINS = [5760770665]

# Sudoers têm acesso total ao servidor e podem executar comandos.
SUDOERS = [5760770665]

# Todos os sudoers também devem ser administradores.
ADMINS.extend(SUDOERS)

GIFTERS = [5760770665]

# Bote o Username do bot sem o @
# Exemplo: default
BOT_LINK = "afxsearchbot"


# Bote o Username do suporte sem o @
# Exemplo: suporte
BOT_LINK_SUPORTE = "afxtrem7search"
##```